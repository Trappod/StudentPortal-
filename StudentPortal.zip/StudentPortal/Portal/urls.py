from django.urls import path
from . import views

urlpatterns = [
    path('Login/', views.Login, name='Login'),  # URL for the login page
    path('Dashboard/', views.Dashboard, name='Dashboard'),  # URL for the dashboard page
    # Add more URL patterns for other functionalities as needed
]
