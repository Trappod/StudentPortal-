from django.shortcuts import render, redirect
    from django.contrib.auth import authenticate, Login
from django.contrib.auth.decorators import Login_required

def student_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('Dashboard')  # Redirect to dashboard upon successful login
        else:
            return render(request, 'Portal/Login.html', {'error_message': 'Invalid credentials'})
    return render(request, 'Portal/Login.html')

@login_required
def dashboard(request):
    # Add logic to fetch data for the dashboard
    return render(request, 'Portal/Dashboard.html')
